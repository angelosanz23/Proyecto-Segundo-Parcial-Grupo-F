package ec.edu.proyecto;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CalculadoraTest {

    @Test
    public void testSuma() {
        Calculadora c = new Calculadora();
        assertEquals(10, c.sumar(7, 3));
    }

    @Test
    public void testResta() {
        Calculadora c = new Calculadora();
        assertEquals(4, c.restar(7, 3));
    }
}
